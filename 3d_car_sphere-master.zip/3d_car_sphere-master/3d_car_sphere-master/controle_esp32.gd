extends Node

# Cria o objeto que vai escutar a rede UDP
var udp := PacketPeerUDP.new()
const PORT = 4242

# Define a sensibilidade da inclinação (ajuste esses valores se necessário)
# 0.25 significa cerca de 25% da força da gravidade (uma inclinação suave)
const ZONA_MORTA = 0.25 

func _ready():
	# Inicia a escuta na porta definida
	var erro = udp.bind(PORT)
	if erro == OK:
		print("Pronto! Escutando o controle do ESP32 na porta: ", PORT)
	else:
		print("Erro ao tentar escutar a porta UDP.")

func _process(_delta):
	# Verifica se chegou alguma mensagem do ESP32
	if udp.get_available_packet_count() > 0:
		# Lê a mensagem e converte de bytes para texto
		var pacote = udp.get_packet().get_string_from_utf8()
		_processar_comandos(pacote)

func _processar_comandos(dados: String):
	# Divide a mensagem "Y,X" em dois valores usando a vírgula como separador
	var eixos = dados.split(",")
	
	if eixos.size() >= 2:
		var inclinacao_y = eixos[0].to_float() * -1.0 # Frente e trás
		var inclinacao_x = eixos[1].to_float() * -1.0 # Esquerda e direita
		
		# --- LÓGICA DE ACELERAR E FREAR (EIXO Y) ---
		# Dependendo da orientação física da sua placa, pode ser necessário 
		# inverter os sinais de > e < abaixo.
		if inclinacao_y < -ZONA_MORTA:
			Input.action_press("accelerate")
			Input.action_release("brake")
		elif inclinacao_y > ZONA_MORTA:
			Input.action_press("brake")
			Input.action_release("accelerate")
		else:
			# Se a placa estiver reta, solta os dois botões
			Input.action_release("accelerate")
			Input.action_release("brake")

		# --- LÓGICA DE DIREÇÃO (EIXO X) ---
		if inclinacao_x > ZONA_MORTA:
			Input.action_press("steer_right")
			Input.action_release("steer_left")
		elif inclinacao_x < -ZONA_MORTA:
			Input.action_press("steer_left")
			Input.action_release("steer_right")
		else:
			# Se a placa estiver reta, solta a direção
			Input.action_release("steer_right")
			Input.action_release("steer_left")
